package com.fh.entity.backend;

import java.util.List;

/** 
 * 说明：风险 实体类
 * 创建人：FH Q313596790
 * 创建时间：2023-09-28
 */
public class M_fengxian{ 
	private String FENGXIAN_ID;			//风险id
	private int ISDEL;				//是否删除1删除0未删除
	private int SORT;				//排序
	private String CREATER;			//创建人
	private String CREATE_DATE;			//创建时间
	private String MODIFYER;			//修改人
	private String MODIFY_DATE;			//修改时间
	private String SECOND_UNIT;			//二级公司
	private String THIRD_UNIT;			//三级机构
	private String FENGXIAN_ADDRESS;			//地址
	private String FENGXIAN_AREA;			//区域
	private String FENGXIAN_HAZARD;			//危险源
	private String FENGXIAN_ACCIDENT_TYPE;			//可能导致的事故类型
	private String FENGXIAN_LEVEL;			//风险等级
	private String CONTROL_MEASURE;			//控制措施
	private String EMERGENCY_MEASURE;			//应急措施
	private String HAZARD_DURATION;			//危险源持续时间
	private String MANAGEMENT_LEVEL;			//管理层级
	private String RESPONSIBILITY UNIT;			//责任单位(组织机构)
	private String RESPONSIBILITY_PEPOLE;			//责任人
	private String RESPONSIBILITY_PHONE;			//责任人联系方式
	private String RECOGNITION TIME;			//识别时间
	private String DURANTION_CIRCLE;			//持续周期
	public String getFENGXIAN_ID() {
		return FENGXIAN_ID;
	}
	public void setFENGXIAN_ID(String FENGXIAN_ID) {
		this.FENGXIAN_ID = FENGXIAN_ID;
	}
	public int getISDEL() {
		return ISDEL;
	}
	public void setISDEL(int ISDEL) {
		this.ISDEL = ISDEL;
	}
	public int getSORT() {
		return SORT;
	}
	public void setSORT(int SORT) {
		this.SORT = SORT;
	}
	public String getCREATER() {
		return CREATER;
	}
	public void setCREATER(String CREATER) {
		this.CREATER = CREATER;
	}
	public String getCREATE_DATE() {
		return CREATE_DATE;
	}
	public void setCREATE_DATE(String CREATE_DATE) {
		this.CREATE_DATE = CREATE_DATE;
	}
	public String getMODIFYER() {
		return MODIFYER;
	}
	public void setMODIFYER(String MODIFYER) {
		this.MODIFYER = MODIFYER;
	}
	public String getMODIFY_DATE() {
		return MODIFY_DATE;
	}
	public void setMODIFY_DATE(String MODIFY_DATE) {
		this.MODIFY_DATE = MODIFY_DATE;
	}
	public String getSECOND_UNIT() {
		return SECOND_UNIT;
	}
	public void setSECOND_UNIT(String SECOND_UNIT) {
		this.SECOND_UNIT = SECOND_UNIT;
	}
	public String getTHIRD_UNIT() {
		return THIRD_UNIT;
	}
	public void setTHIRD_UNIT(String THIRD_UNIT) {
		this.THIRD_UNIT = THIRD_UNIT;
	}
	public String getFENGXIAN_ADDRESS() {
		return FENGXIAN_ADDRESS;
	}
	public void setFENGXIAN_ADDRESS(String FENGXIAN_ADDRESS) {
		this.FENGXIAN_ADDRESS = FENGXIAN_ADDRESS;
	}
	public String getFENGXIAN_AREA() {
		return FENGXIAN_AREA;
	}
	public void setFENGXIAN_AREA(String FENGXIAN_AREA) {
		this.FENGXIAN_AREA = FENGXIAN_AREA;
	}
	public String getFENGXIAN_HAZARD() {
		return FENGXIAN_HAZARD;
	}
	public void setFENGXIAN_HAZARD(String FENGXIAN_HAZARD) {
		this.FENGXIAN_HAZARD = FENGXIAN_HAZARD;
	}
	public String getFENGXIAN_ACCIDENT_TYPE() {
		return FENGXIAN_ACCIDENT_TYPE;
	}
	public void setFENGXIAN_ACCIDENT_TYPE(String FENGXIAN_ACCIDENT_TYPE) {
		this.FENGXIAN_ACCIDENT_TYPE = FENGXIAN_ACCIDENT_TYPE;
	}
	public String getFENGXIAN_LEVEL() {
		return FENGXIAN_LEVEL;
	}
	public void setFENGXIAN_LEVEL(String FENGXIAN_LEVEL) {
		this.FENGXIAN_LEVEL = FENGXIAN_LEVEL;
	}
	public String getCONTROL_MEASURE() {
		return CONTROL_MEASURE;
	}
	public void setCONTROL_MEASURE(String CONTROL_MEASURE) {
		this.CONTROL_MEASURE = CONTROL_MEASURE;
	}
	public String getEMERGENCY_MEASURE() {
		return EMERGENCY_MEASURE;
	}
	public void setEMERGENCY_MEASURE(String EMERGENCY_MEASURE) {
		this.EMERGENCY_MEASURE = EMERGENCY_MEASURE;
	}
	public String getHAZARD_DURATION() {
		return HAZARD_DURATION;
	}
	public void setHAZARD_DURATION(String HAZARD_DURATION) {
		this.HAZARD_DURATION = HAZARD_DURATION;
	}
	public String getMANAGEMENT_LEVEL() {
		return MANAGEMENT_LEVEL;
	}
	public void setMANAGEMENT_LEVEL(String MANAGEMENT_LEVEL) {
		this.MANAGEMENT_LEVEL = MANAGEMENT_LEVEL;
	}
	public String getRESPONSIBILITY UNIT() {
		return RESPONSIBILITY UNIT;
	}
	public void setRESPONSIBILITY UNIT(String RESPONSIBILITY UNIT) {
		this.RESPONSIBILITY UNIT = RESPONSIBILITY UNIT;
	}
	public String getRESPONSIBILITY_PEPOLE() {
		return RESPONSIBILITY_PEPOLE;
	}
	public void setRESPONSIBILITY_PEPOLE(String RESPONSIBILITY_PEPOLE) {
		this.RESPONSIBILITY_PEPOLE = RESPONSIBILITY_PEPOLE;
	}
	public String getRESPONSIBILITY_PHONE() {
		return RESPONSIBILITY_PHONE;
	}
	public void setRESPONSIBILITY_PHONE(String RESPONSIBILITY_PHONE) {
		this.RESPONSIBILITY_PHONE = RESPONSIBILITY_PHONE;
	}
	public String getRECOGNITION TIME() {
		return RECOGNITION TIME;
	}
	public void setRECOGNITION TIME(String RECOGNITION TIME) {
		this.RECOGNITION TIME = RECOGNITION TIME;
	}
	public String getDURANTION_CIRCLE() {
		return DURANTION_CIRCLE;
	}
	public void setDURANTION_CIRCLE(String DURANTION_CIRCLE) {
		this.DURANTION_CIRCLE = DURANTION_CIRCLE;
	}

}
